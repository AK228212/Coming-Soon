<?php
    include('db.php');
    $query = 'select * from demo';
    $run = mysqli_query($conn, $query);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <h1>Contacting details</h1>
    <table>
        <tr>
            <th >Email</th>
            <th>Message</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($run)): ?>
        <tr>
            <td>
            <a href="mailto:<?php echo $row['email']?>?subject=organisational mail&body=your message was: <?php echo $row['message']?>">
                <?php echo $row['email']?></a>
            </td>
            <td><?php echo $row['message']?></td>
        </tr>
        <?php endwhile ;?>
    </table>
</body>
</html>