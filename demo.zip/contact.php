<?php

    include('db.php');
    //variables
    $email = $_POST['email'];
    $message = $_POST['message'];



    //check fields
    if(empty($email) || empty($message))
    {
        echo "Please! Fill the details.";
    }
    else
    {
        $query = "insert into demo(email,message) value('$email', '$message')";

        $mySql = mysqli_query($conn, $query);

        if(isset($mySql)){
            header("location:http://localhost/coming soon/index.php");
        }
        else{
            echo "Data not saved";
        }
    }
?>